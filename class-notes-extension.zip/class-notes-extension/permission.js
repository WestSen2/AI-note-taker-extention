document.getElementById("go").onclick = async () => {
  const msg = document.getElementById("msg");
  try {
    (await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach(t => t.stop());
    msg.textContent = "Microphone allowed. You can close this tab and press Start in the side panel.";
  } catch { msg.textContent = "Access was blocked. Click the lock icon in the address bar, allow the microphone, and try again."; }
};
