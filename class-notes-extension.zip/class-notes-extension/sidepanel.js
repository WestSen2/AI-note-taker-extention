const $ = s => document.querySelector(s);
const API = "https://api.anthropic.com/v1/messages", MODEL = "claude-sonnet-5-5";
const CATS = ["Deadlines and tests", "Homework", "Definitions", "Key points"];
const SYSTEM = `You turn a live classroom transcript into study notes.
Each line looks like: [id] time text. Lines are not labelled by speaker: the teacher speaks most of the time and a student occasionally asks or answers a question.
Rules:
- Use ONLY what the teacher actually said. Never add facts, dates or numbers that are not in the transcript.
- Skip student questions, small talk and off-topic chatter, unless the teacher's answer contains something worth noting.
- Watch for emphasis cues: "this will be on the test", "remember", "make sure", repetition.
- Each note is one short, self-contained sentence and points to the single line that best supports it via line_id.
- Merge duplicates. Keep the list tight.
- category must be exactly one of: ${CATS.map(c => `"${c}"`).join(", ")}.
Reply with JSON only, no prose and no code fences:
{"items":[{"category":"...","text":"...","line_id":0}]}`;

let lines = [], cats = {}, key = "", running = false, t0 = 0, tick, recog, lastAI = 0, busy = false, sentCount = 0;
const fmt = s => Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0");
const esc = s => s.replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const status = t => $("#status").textContent = t;
const hdr = k => ({ "content-type": "application/json", "x-api-key": k, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" });
const save = () => chrome.storage.local.set({ session: { lines, cats } });
const show = v => { $("#notes").hidden = v !== "notes"; $("#settings").hidden = v !== "settings"; };

async function init() {
  const s = await chrome.storage.local.get(["apiKey", "session"]);
  key = s.apiKey || ""; $("#key").value = key;
  if (s.session) { lines = s.session.lines; cats = s.session.cats; if (lines.length) $("#transcript").innerHTML = ""; lines.forEach(renderLine); }
  renderSummary();
  if (!key) { show("settings"); $("#keyMsg").textContent = "Paste your API key to turn on AI summaries."; }
}

function renderLine(l) {
  const box = $("#transcript"), d = document.createElement("div");
  d.className = "line"; d.id = "l" + l.id;
  d.innerHTML = `<time>${l.time}</time><div>${esc(l.text)}</div>`;
  box.appendChild(d); box.scrollTop = box.scrollHeight;
}
function addLine(text) {
  if (!text) return;
  const l = { id: lines.length, time: fmt((Date.now() - t0) / 1000), text };
  if (!l.id) $("#transcript").innerHTML = "";
  lines.push(l); renderLine(l); save();
}
function renderSummary() {
  const html = CATS.filter(n => cats[n]?.length).map(n =>
    `<div class="cat"><h3>${n}</h3>` + cats[n].map(i =>
      `<div class="item"><a data-id="${i.id}">${esc(i.text)}</a><time>${i.time}</time><button data-copy="${i.id}" data-text="${esc(i.text).replace(/"/g, "&quot;")}">Copy</button></div>`).join("") + "</div>").join("");
  $("#summary").innerHTML = html || `<div class="empty">${key ? "Key points, deadlines and homework will collect here." : "Add an API key in Settings to get AI summaries."}</div>`;
}
async function aiSummarize() {
  if (busy || !key || !lines.length || lines.length === sentCount) return;
  busy = true; lastAI = Date.now(); const n = lines.length;
  try {
    const transcript = lines.map(l => `[${l.id}] ${l.time} ${l.text}`).join("\n");
    const r = await fetch(API, { method: "POST", headers: hdr(key), body: JSON.stringify({ model: MODEL, max_tokens: 1500, system: SYSTEM, messages: [{ role: "user", content: transcript }] }) });
    if (r.status === 401) throw new Error("key");
    if (!r.ok) throw new Error("HTTP " + r.status);
    const data = await r.json();
    const out = JSON.parse(data.content.map(b => b.text || "").join("").replace(/```json|```/g, "").trim());
    const next = {};
    for (const it of out.items || []) {
      const l = lines[it.line_id]; if (!l) continue;
      const name = CATS.includes(it.category) ? it.category : "Key points";
      (next[name] ??= []).push({ id: l.id, text: it.text, time: l.time });
    }
    cats = next; sentCount = n; renderSummary(); save(); status("Summary updated " + new Date().toLocaleTimeString());
  } catch (e) {
    status(e.message === "key" ? "Your API key was rejected. Check it in Settings." : "Summary update failed (" + e.message + "). Will retry.");
  }
  busy = false;
}

function start() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { status("Speech recognition isn't available in this browser."); return; }
  lines = []; cats = {}; sentCount = 0; $("#transcript").innerHTML = ""; renderSummary(); save(); status("");
  recog = new SR(); recog.continuous = true; recog.interimResults = false; recog.lang = "en-US";
  recog.onresult = e => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) addLine(e.results[i][0].transcript.trim()); };
  recog.onend = () => { if (running) try { recog.start(); } catch {} };
  recog.onerror = e => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { stop(); show("settings"); $("#keyMsg").textContent = "Microphone is blocked. Choose Allow microphone below."; } };
  recog.start(); running = true; t0 = Date.now(); lastAI = Date.now();
  tick = setInterval(() => { $("#timer").textContent = fmt((Date.now() - t0) / 1000); if (Date.now() - lastAI > 45000) aiSummarize(); }, 500);
  $("#rec").textContent = "Stop"; $("#rec").classList.add("on");
}
function stop() {
  running = false; clearInterval(tick);
  if (recog) { recog.onend = null; try { recog.stop(); } catch {} }
  $("#rec").textContent = "Start"; $("#rec").classList.remove("on");
  aiSummarize();
}

async function copy(text, btn) {
  await navigator.clipboard.writeText(text);
  const o = btn.textContent; btn.textContent = "Copied"; setTimeout(() => btn.textContent = o, 1200);
}
$("#summary").onclick = e => {
  const a = e.target.closest("a[data-id]");
  if (a) { const el = $("#l" + a.dataset.id); el?.scrollIntoView({ block: "center", behavior: "smooth" }); el?.classList.add("hit"); setTimeout(() => el?.classList.remove("hit"), 1600); }
  const c = e.target.closest("button[data-copy]"); if (c) copy(c.dataset.text, c);
};
$("#copyT").onclick = e => copy(lines.map(l => `[${l.time}] ${l.text}`).join("\n"), e.target);
$("#copyS").onclick = e => copy(CATS.filter(n => cats[n]?.length).map(n => `## ${n}\n` + cats[n].map(i => `- ${i.text} (${i.time})`).join("\n")).join("\n\n"), e.target);
$("#rec").onclick = () => running ? stop() : start();
$("#gear").onclick = () => show("settings");
$("#back").onclick = () => show("notes");
$("#show").onclick = e => { const k = $("#key"); k.type = k.type === "password" ? "text" : "password"; e.target.textContent = k.type === "password" ? "Show" : "Hide"; };
$("#mic").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("permission.html") });
$("#saveKey").onclick = async () => {
  const k = $("#key").value.trim(), msg = $("#keyMsg");
  if (!k) { await chrome.storage.local.remove("apiKey"); key = ""; msg.textContent = "Key removed."; renderSummary(); return; }
  msg.textContent = "Checking key...";
  try {
    const r = await fetch(API, { method: "POST", headers: hdr(k), body: JSON.stringify({ model: MODEL, max_tokens: 1, messages: [{ role: "user", content: "hi" }] }) });
    if (r.status === 401) { msg.textContent = "That key was rejected. Check that you copied all of it."; return; }
    await chrome.storage.local.set({ apiKey: k }); key = k; renderSummary();
    msg.textContent = r.ok ? "Key saved and working." : "Key saved, but a test call returned HTTP " + r.status + ". Check your Anthropic account has credits.";
    if (r.ok) setTimeout(() => show("notes"), 900);
  } catch { msg.textContent = "Couldn't reach Anthropic. Check your connection and try again."; }
};
init();
